package ages.hopeful;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HopefulApplication {

	public static void main(String[] args) {
		SpringApplication.run(HopefulApplication.class, args);
	}

}
