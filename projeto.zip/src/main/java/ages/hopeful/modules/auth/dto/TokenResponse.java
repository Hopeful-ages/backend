package ages.hopeful.modules.auth.dto;

import lombok.*;

@Getter 
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TokenResponse {
    private String token;
}
