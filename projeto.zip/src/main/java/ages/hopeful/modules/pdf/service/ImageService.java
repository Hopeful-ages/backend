package ages.hopeful.modules.pdf.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.Base64;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

@Component
public class ImageService {

    public String getWatermarkImageBase64() {
        ClassPathResource resource = new ClassPathResource("images/hopeful_pdf_logo.png");
        try (InputStream is = resource.getInputStream()) {
            byte[] imageBytes = is.readAllBytes();
            return Base64.getEncoder().encodeToString(imageBytes);
        } catch (IOException e) {
            return null;
        }
    }
}