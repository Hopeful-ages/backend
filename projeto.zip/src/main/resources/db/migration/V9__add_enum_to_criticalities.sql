CREATE TYPE criticality_phase AS ENUM ('antes', 'durante', 'depois');
