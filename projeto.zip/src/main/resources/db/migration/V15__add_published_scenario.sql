ALTER TABLE scenarios
ADD COLUMN published BOOLEAN DEFAULT false;
