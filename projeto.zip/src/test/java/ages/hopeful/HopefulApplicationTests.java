package ages.hopeful;

import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@ActiveProfiles("test") 

class HopefulApplicationTests {

	@Test
	void contextLoads() {
	}

}
